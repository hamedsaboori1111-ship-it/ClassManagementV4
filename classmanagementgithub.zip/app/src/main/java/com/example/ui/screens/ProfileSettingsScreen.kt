package com.example.ui.screens

import android.widget.Toast
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.model.ProfileSettings
import com.example.security.BiometricAvailability
import com.example.security.SecurityManager
import com.example.security.SecurityType
import com.example.ui.components.PatternLockView
import com.example.ui.components.PinKeypadView
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSettingsScreen(
    profile: ProfileSettings,
    onBack: () -> Unit,
    onSaveProfile: (teacherName: String, educationalTitle: String, schoolName: String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity

    var teacherName by remember(profile) { mutableStateOf(profile.teacherName) }
    var educationalTitle by remember(profile) { mutableStateOf(profile.educationalTitle) }
    var schoolName by remember(profile) { mutableStateOf(profile.schoolName) }

    var classTitleError by remember { mutableStateOf<String?>(null) }
    var isEditing by remember { mutableStateOf(false) }

    // Security state
    var currentSecurityType by remember { mutableStateOf(SecurityManager.getSecurityType(context)) }
    var savedPin by remember { mutableStateOf(SecurityManager.getPin(context)) }
    var savedPattern by remember { mutableStateOf(SecurityManager.getPattern(context)) }
    val biometricStatus by remember { mutableStateOf(SecurityManager.checkBiometricStatus(context)) }
    val isInitialSetupDone by remember { mutableStateOf(SecurityManager.isInitialSetupDone(context)) }

    // Dialogs state
    var showPinDialog by remember { mutableStateOf(false) }
    var showPatternDialog by remember { mutableStateOf(false) }
    var showBiometricInfoDialog by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تنظیمات پروفایل و مشخصات کلاس",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryGreen,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // کارت پیش‌نمایش نشان / کارت هویت معلم و مدرسه
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // آیکون گرد پروفایل
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(PrimaryGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "تصویر پروفایل",
                            tint = PrimaryGreen,
                            modifier = Modifier.size(54.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = teacherName.ifBlank { "نام معلم وارد نشده" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = AmberSecondaryLight,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = educationalTitle.ifBlank { "عنوان و شماره کلاس" },
                            color = Color(0xFFB45309),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = SkyBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = schoolName.ifBlank { "نام مدرسه وارد نشده" },
                            fontSize = 14.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // کارت فرم ورودی / ویرایش اطلاعات
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مشخصات حساب و اطلاعات کلاس",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    // فیلد ۱: نام معلم
                    OutlinedTextField(
                        value = teacherName,
                        onValueChange = { teacherName = it },
                        label = { Text("نام و نام‌خانوادگی معلم") },
                        placeholder = { Text("مثلاً: آقای محمد رضایی") },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryGreen)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("teacher_name_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // فیلد ۲: عنوان و شماره کلاس (فقط حروف فارسی، بدون عدد و نشانه)
                    OutlinedTextField(
                        value = educationalTitle,
                        onValueChange = { input ->
                            val hasDisallowed = input.any { c ->
                                val code = c.code
                                val isAllowedPersian = (code in 0x0621..0x064A) ||
                                        code == 0x067E || code == 0x0686 || code == 0x0698 ||
                                        code == 0x06A9 || code == 0x06AF || code == 0x06CC ||
                                        code == 0x06C0 || (code in 0x064B..0x0652) ||
                                        c == ' ' || c == '\u200C'
                                !isAllowedPersian
                            }
                            if (hasDisallowed) {
                                classTitleError = "استفاده از اعداد و نشانه‌ها غیرمجاز است؛ لطفاً فقط از حروف فارسی استفاده کنید."
                                educationalTitle = input.filter { c ->
                                    val code = c.code
                                    (code in 0x0621..0x064A) ||
                                            code == 0x067E || code == 0x0686 || code == 0x0698 ||
                                            code == 0x06A9 || code == 0x06AF || code == 0x06CC ||
                                            code == 0x06C0 || (code in 0x064B..0x0652) ||
                                            c == ' ' || c == '\u200C'
                                }
                            } else {
                                classTitleError = null
                                educationalTitle = input
                            }
                        },
                        label = { Text("عنوان و شماره کلاس") },
                        placeholder = { Text("مثلاً: کلاس چهارم الف یا پایه ششم ب") },
                        leadingIcon = {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = AmberSecondary)
                        },
                        isError = classTitleError != null,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("educational_title_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (classTitleError != null) {
                        Row(
                            modifier = Modifier.padding(start = 6.dp, top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = classTitleError ?: "",
                                color = Color(0xFFDC2626),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // فیلد ۳: نام مدرسه
                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = { schoolName = it },
                        label = { Text("نام مدرسه یا مرکز آموزشی") },
                        placeholder = { Text("مثلاً: دبستان غیردولتی دانش") },
                        leadingIcon = {
                            Icon(Icons.Default.Apartment, contentDescription = null, tint = SkyBlue)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_name_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // دکمه ذخیره تنظیمات پروفایل
                    Button(
                        onClick = {
                            onSaveProfile(
                                teacherName.trim(),
                                educationalTitle.trim(),
                                schoolName.trim()
                            )
                            Toast.makeText(context, "اطلاعات پروفایل با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_profile_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ذخیره تغییرات پروفایل",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // کارت امنیت ورود به برنامه (رمز، الگو و اثر انگشت)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("security_settings_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "امنیت ورود به برنامه",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ورود با رمز عبور، الگو یا اثر انگشت",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        // وضعیت فعلی
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = when (currentSecurityType) {
                                SecurityType.NONE -> Color(0xFFF1F5F9)
                                else -> Color(0xFFDCFCE7)
                            }
                        ) {
                            Text(
                                text = when (currentSecurityType) {
                                    SecurityType.NONE -> "غیرفعال"
                                    SecurityType.PIN -> "رمز عبور فعال"
                                    SecurityType.PATTERN -> "الگو فعال"
                                    SecurityType.FINGERPRINT -> "اثر انگشت فعال"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (currentSecurityType) {
                                    SecurityType.NONE -> Color(0xFF64748B)
                                    else -> Color(0xFF15803D)
                                },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    if (!isInitialSetupDone) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = AmberSecondaryLight,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جهت محافظت از اطلاعات دانش‌آموزان و نمرات کلاسی، توصیه می‌شود یکی از حالت‌های زیر را فعال فرمایید.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF92400E),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // روش ۱: اثر انگشت (مخصوص گوشی‌های دارای حسگر)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (biometricStatus == BiometricAvailability.AVAILABLE) {
                                    if (activity != null) {
                                        val executor = ContextCompat.getMainExecutor(context)
                                        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                                            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                                super.onAuthenticationSucceeded(result)
                                                SecurityManager.setSecurityType(context, SecurityType.FINGERPRINT)
                                                SecurityManager.setInitialSetupDone(context, true)
                                                currentSecurityType = SecurityType.FINGERPRINT
                                                Toast.makeText(context, "ورود با اثر انگشت با موفقیت فعال شد", Toast.LENGTH_SHORT).show()
                                            }
                                            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                                super.onAuthenticationError(errorCode, errString)
                                                Toast.makeText(context, "خطا در تست اثر انگشت: $errString", Toast.LENGTH_SHORT).show()
                                            }
                                        })
                                        val info = BiometricPrompt.PromptInfo.Builder()
                                            .setTitle("فعال‌سازی ورود با اثر انگشت")
                                            .setSubtitle("تست حسگر اثر انگشت")
                                            .setDescription("جهت تأیید، انگشت خود را روی حسگر قرار دهید")
                                            .setNegativeButtonText("انصراف")
                                            .build()
                                        prompt.authenticate(info)
                                    }
                                } else {
                                    showBiometricInfoDialog = biometricStatus.getStatusMessage()
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (currentSecurityType == SecurityType.FINGERPRINT) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFF8FAFC),
                        border = BorderStroke(
                            1.dp,
                            if (currentSecurityType == SecurityType.FINGERPRINT) PrimaryGreen else Color(0xFFE2E8F0)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (currentSecurityType == SecurityType.FINGERPRINT),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = if (currentSecurityType == SecurityType.FINGERPRINT) PrimaryGreen else Color(0xFF475569),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "ورود با اثر انگشت (Fingerprint)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = when (biometricStatus) {
                                        BiometricAvailability.AVAILABLE -> "سنسور اثر انگشت فعال و آماده است"
                                        BiometricAvailability.NONE_ENROLLED -> "سنسور موجود است؛ ثبت اثر انگشت در تنظیمات گوشی لازم است"
                                        BiometricAvailability.NO_HARDWARE -> "این گوشی فاقد حسگر سخت‌افزاری اثر انگشت است"
                                        BiometricAvailability.UNSUPPORTED -> "امکان استفاده از اثر انگشت در این نسخه نیست"
                                    },
                                    fontSize = 11.sp,
                                    color = when (biometricStatus) {
                                        BiometricAvailability.AVAILABLE -> Color(0xFF16A34A)
                                        BiometricAvailability.NONE_ENROLLED -> Color(0xFFD97706)
                                        else -> Color(0xFF94A3B8)
                                    }
                                )
                            }
                            if (biometricStatus == BiometricAvailability.AVAILABLE) {
                                OutlinedButton(
                                    onClick = {
                                        if (activity != null) {
                                            val executor = ContextCompat.getMainExecutor(context)
                                            val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                                                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                                                    super.onAuthenticationSucceeded(result)
                                                    SecurityManager.setSecurityType(context, SecurityType.FINGERPRINT)
                                                    SecurityManager.setInitialSetupDone(context, true)
                                                    currentSecurityType = SecurityType.FINGERPRINT
                                                    Toast.makeText(context, "ورود با اثر انگشت با موفقیت فعال شد", Toast.LENGTH_SHORT).show()
                                                }
                                                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                                    super.onAuthenticationError(errorCode, errString)
                                                    Toast.makeText(context, "خطا: $errString", Toast.LENGTH_SHORT).show()
                                                }
                                            })
                                            val info = BiometricPrompt.PromptInfo.Builder()
                                                .setTitle("فعال‌سازی ورود با اثر انگشت")
                                                .setSubtitle("تست حسگر اثر انگشت")
                                                .setDescription("جهت تأیید، انگشت خود را روی حسگر قرار دهید")
                                                .setNegativeButtonText("انصراف")
                                                .build()
                                            prompt.authenticate(info)
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("تست و فعال‌سازی", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // روش ۲: رمز عبور عددی (PIN)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showPinDialog = true
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (currentSecurityType == SecurityType.PIN) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFF8FAFC),
                        border = BorderStroke(
                            1.dp,
                            if (currentSecurityType == SecurityType.PIN) PrimaryGreen else Color(0xFFE2E8F0)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (currentSecurityType == SecurityType.PIN),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Pin,
                                contentDescription = null,
                                tint = if (currentSecurityType == SecurityType.PIN) PrimaryGreen else Color(0xFF475569),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "رمز عبور عددی (PIN)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (savedPin.isNotBlank()) "رمز تنظیم شده است (${savedPin.length} رقمی)" else "هنوز رمزی تعیین نشده است",
                                    fontSize = 11.sp,
                                    color = if (savedPin.isNotBlank()) Color(0xFF16A34A) else Color(0xFF64748B)
                                )
                            }
                            OutlinedButton(
                                onClick = { showPinDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (savedPin.isBlank()) "تعیین رمز" else "تغییر رمز",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // روش ۳: الگوی تصویری (Pattern)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showPatternDialog = true
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (currentSecurityType == SecurityType.PATTERN) PrimaryGreen.copy(alpha = 0.08f) else Color(0xFFF8FAFC),
                        border = BorderStroke(
                            1.dp,
                            if (currentSecurityType == SecurityType.PATTERN) PrimaryGreen else Color(0xFFE2E8F0)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (currentSecurityType == SecurityType.PATTERN),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (currentSecurityType == SecurityType.PATTERN) PrimaryGreen else Color(0xFF475569),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الگوی تصویری (Pattern)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (savedPattern.isNotEmpty()) "الگو تنظیم شده است (${savedPattern.size} نقطه)" else "هنوز الگویی تعیین نشده است",
                                    fontSize = 11.sp,
                                    color = if (savedPattern.isNotEmpty()) Color(0xFF16A34A) else Color(0xFF64748B)
                                )
                            }
                            OutlinedButton(
                                onClick = { showPatternDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (savedPattern.isEmpty()) "ترسیم الگو" else "تغییر الگو",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // روش ۴: غیرفعال (بدون قفل)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                SecurityManager.setSecurityType(context, SecurityType.NONE)
                                SecurityManager.setInitialSetupDone(context, true)
                                currentSecurityType = SecurityType.NONE
                                Toast.makeText(context, "قفل برنامه غیرفعال شد", Toast.LENGTH_SHORT).show()
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (currentSecurityType == SecurityType.NONE) Color(0xFFF1F5F9) else Color(0xFFF8FAFC),
                        border = BorderStroke(
                            1.dp,
                            if (currentSecurityType == SecurityType.NONE) Color(0xFF94A3B8) else Color(0xFFE2E8F0)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (currentSecurityType == SecurityType.NONE),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF64748B))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "غیرفعال (بدون قفل)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ورود مستقیم به برنامه بدون نیاز به رمز یا اثر انگشت",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // دیالوگ تنظیم / تغییر رمز عبور عددی (PIN)
            if (showPinDialog) {
                var step by remember { mutableStateOf(1) } // 1: enter new, 2: confirm new
                var firstPin by remember { mutableStateOf("") }
                var secondPin by remember { mutableStateOf("") }
                var pinDialogError by remember { mutableStateOf<String?>(null) }

                AlertDialog(
                    onDismissRequest = { showPinDialog = false },
                    title = {
                        Text(
                            text = if (savedPin.isBlank()) "تعیین رمز عبور عددی" else "تغییر رمز عبور عددی",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = PrimaryGreen
                        )
                    },
                    text = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (step == 1) "رمز ۴ رقمی جدید خود را وارد کنید:" else "جهت تأیید، رمز جدید را مجدداً وارد کنید:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF334155),
                                textAlign = TextAlign.Center
                            )

                            if (pinDialogError != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = pinDialogError ?: "",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFEF4444),
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            PinKeypadView(
                                pinLength = 4,
                                currentLength = if (step == 1) firstPin.length else secondPin.length,
                                isError = pinDialogError != null,
                                onDigitClick = { digit ->
                                    pinDialogError = null
                                    if (step == 1) {
                                        if (firstPin.length < 4) {
                                            firstPin += digit
                                            if (firstPin.length == 4) {
                                                step = 2
                                            }
                                        }
                                    } else {
                                        if (secondPin.length < 4) {
                                            secondPin += digit
                                            if (secondPin.length == 4) {
                                                if (firstPin == secondPin) {
                                                    SecurityManager.setPin(context, firstPin)
                                                    SecurityManager.setSecurityType(context, SecurityType.PIN)
                                                    SecurityManager.setInitialSetupDone(context, true)
                                                    savedPin = firstPin
                                                    currentSecurityType = SecurityType.PIN
                                                    showPinDialog = false
                                                    Toast.makeText(context, "رمز عبور با موفقیت تنظیم و فعال شد", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    pinDialogError = "رمزهای وارد شده مطابقت ندارند، لطفاً مجدداً امتحان کنید"
                                                    secondPin = ""
                                                    step = 1
                                                    firstPin = ""
                                                }
                                            }
                                        }
                                    }
                                },
                                onBackspaceClick = {
                                    if (step == 1 && firstPin.isNotEmpty()) {
                                        firstPin = firstPin.dropLast(1)
                                    } else if (step == 2 && secondPin.isNotEmpty()) {
                                        secondPin = secondPin.dropLast(1)
                                    }
                                },
                                onClearClick = {
                                    if (step == 1) firstPin = "" else secondPin = ""
                                }
                            )
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showPinDialog = false }) {
                            Text("انصراف")
                        }
                    }
                )
            }

            // دیالوگ تنظیم / تغییر الگوی تصویری (Pattern)
            if (showPatternDialog) {
                var step by remember { mutableStateOf(1) } // 1: draw new, 2: confirm new
                var firstPattern by remember { mutableStateOf<List<Int>>(emptyList()) }
                var patternDialogError by remember { mutableStateOf<String?>(null) }
                var patternIsError by remember { mutableStateOf(false) }

                AlertDialog(
                    onDismissRequest = { showPatternDialog = false },
                    title = {
                        Text(
                            text = if (savedPattern.isEmpty()) "تعیین الگوی تصویری" else "تغییر الگوی تصویری",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = PrimaryGreen
                        )
                    },
                    text = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (step == 1) "الگوی تصویری جدید را رسم کنید (حداقل ۴ نقطه):" else "جهت تأیید، الگو را مجدداً رسم کنید:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF334155),
                                textAlign = TextAlign.Center
                            )

                            if (patternDialogError != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = patternDialogError ?: "",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFEF4444),
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            PatternLockView(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .aspectRatio(1f),
                                isError = patternIsError,
                                onPatternCompleted = { pattern ->
                                    if (pattern.size < 4) {
                                        patternDialogError = "الگو باید حداقل شامل ۴ نقطه باشد"
                                        patternIsError = true
                                    } else {
                                        if (step == 1) {
                                            firstPattern = pattern
                                            step = 2
                                            patternDialogError = null
                                            patternIsError = false
                                        } else {
                                            if (firstPattern == pattern) {
                                                SecurityManager.setPattern(context, pattern)
                                                SecurityManager.setSecurityType(context, SecurityType.PATTERN)
                                                SecurityManager.setInitialSetupDone(context, true)
                                                savedPattern = pattern
                                                currentSecurityType = SecurityType.PATTERN
                                                showPatternDialog = false
                                                Toast.makeText(context, "الگوی ورود با موفقیت ذخیره و فعال شد", Toast.LENGTH_SHORT).show()
                                            } else {
                                                patternDialogError = "الگوها یکسان نیستند، لطفاً از ابتدا رسم کنید"
                                                patternIsError = true
                                                step = 1
                                                firstPattern = emptyList()
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showPatternDialog = false }) {
                            Text("انصراف")
                        }
                    }
                )
            }

            // دیالوگ اطلاعات سنسور اثر انگشت
            showBiometricInfoDialog?.let { message ->
                AlertDialog(
                    onDismissRequest = { showBiometricInfoDialog = null },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null,
                            tint = PrimaryGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    },
                    title = {
                        Text("وضعیت حسگر اثر انگشت", fontWeight = FontWeight.Bold)
                    },
                    text = {
                        Text(message, fontSize = 14.sp, color = TextPrimary)
                    },
                    confirmButton = {
                        Button(
                            onClick = { showBiometricInfoDialog = null },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                        ) {
                            Text("متوجه شدم")
                        }
                    }
                )
            }

            // توضیحات راهنما
            Surface(
                color = PrimaryGreen.copy(alpha = 0.08f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = PrimaryGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "این مشخصات در سربرگ صفحه اصلی، کارنامه‌ها و گزارش‌های کلاسی نمایش داده خواهد شد.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
