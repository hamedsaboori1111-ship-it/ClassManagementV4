package com.example.security

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.biometric.BiometricManager

enum class SecurityType {
    NONE,
    PIN,
    PATTERN,
    FINGERPRINT;

    fun getDisplayName(): String = when (this) {
        NONE -> "غیرفعال (بدون قفل)"
        PIN -> "رمز عبور عددی (PIN)"
        PATTERN -> "الگوی تصویری (Pattern)"
        FINGERPRINT -> "ورود با اثر انگشت (Fingerprint)"
    }
}

enum class BiometricAvailability {
    AVAILABLE,
    NO_HARDWARE,
    NONE_ENROLLED,
    UNSUPPORTED;

    fun getStatusMessage(): String = when (this) {
        AVAILABLE -> "حسگر اثر انگشت فعال و آماده استفاده است."
        NO_HARDWARE -> "این دستگاه فاقد حسگر اثر انگشت فیزیکی می‌باشد."
        NONE_ENROLLED -> "حسگر اثر انگشت موجود است اما هنوز اثر انگشتی در تنظیمات گوشی ثبت نشده است."
        UNSUPPORTED -> "امکان استفاده از اثر انگشت در این نسخه/دستگاه مقدور نیست."
    }
}

object SecurityManager {
    private const val PREFS_NAME = "class_manager_security_prefs"
    private const val KEY_SECURITY_TYPE = "security_type"
    private const val KEY_PIN_CODE = "pin_code"
    private const val KEY_PATTERN_CODE = "pattern_code"
    private const val KEY_INITIAL_SETUP_DONE = "initial_security_setup_done"

    private fun getPrefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getSecurityType(context: Context): SecurityType {
        val str = getPrefs(context).getString(KEY_SECURITY_TYPE, SecurityType.NONE.name) ?: SecurityType.NONE.name
        return try {
            SecurityType.valueOf(str)
        } catch (e: Exception) {
            SecurityType.NONE
        }
    }

    fun setSecurityType(context: Context, type: SecurityType) {
        getPrefs(context).edit().putString(KEY_SECURITY_TYPE, type.name).apply()
    }

    fun getPin(context: Context): String {
        return getPrefs(context).getString(KEY_PIN_CODE, "") ?: ""
    }

    fun setPin(context: Context, pin: String) {
        getPrefs(context).edit().putString(KEY_PIN_CODE, pin).apply()
    }

    fun getPattern(context: Context): List<Int> {
        val str = getPrefs(context).getString(KEY_PATTERN_CODE, "") ?: ""
        if (str.isBlank()) return emptyList()
        return str.split(",").mapNotNull { it.toIntOrNull() }
    }

    fun setPattern(context: Context, pattern: List<Int>) {
        val str = pattern.joinToString(",")
        getPrefs(context).edit().putString(KEY_PATTERN_CODE, str).apply()
    }

    fun isInitialSetupDone(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_INITIAL_SETUP_DONE, false)
    }

    fun setInitialSetupDone(context: Context, done: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_INITIAL_SETUP_DONE, done).apply()
    }

    fun checkBiometricStatus(context: Context): BiometricAvailability {
        return try {
            val biometricManager = BiometricManager.from(context)
            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            when (biometricManager.canAuthenticate(authenticators)) {
                BiometricManager.BIOMETRIC_SUCCESS -> BiometricAvailability.AVAILABLE
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricAvailability.NO_HARDWARE
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricAvailability.NONE_ENROLLED
                else -> BiometricAvailability.UNSUPPORTED
            }
        } catch (e: Exception) {
            BiometricAvailability.UNSUPPORTED
        }
    }

    fun verifyPin(context: Context, entered: String): Boolean {
        val currentPin = getPin(context)
        return currentPin.isNotEmpty() && currentPin == entered.trim()
    }

    fun verifyPattern(context: Context, entered: List<Int>): Boolean {
        val currentPattern = getPattern(context)
        return currentPattern.isNotEmpty() && currentPattern == entered
    }

    @Volatile
    private var temporaryBypassUntil: Long = 0L

    /**
     * Activates a temporary bypass window so file/photo picker operations
     * do not lock the app when the system picker appears in the foreground.
     */
    fun setTemporaryPickerBypass(durationMs: Long = 180_000L) {
        temporaryBypassUntil = System.currentTimeMillis() + durationMs
    }

    fun isBypassActive(): Boolean {
        return System.currentTimeMillis() < temporaryBypassUntil
    }

    fun clearBypass() {
        temporaryBypassUntil = 0L
    }

    fun isSecurityActive(context: Context): Boolean {
        val type = getSecurityType(context)
        return when (type) {
            SecurityType.NONE -> false
            SecurityType.PIN -> getPin(context).isNotBlank()
            SecurityType.PATTERN -> getPattern(context).isNotEmpty()
            SecurityType.FINGERPRINT -> true
        }
    }

    fun vibrate(context: Context, durationMs: Long = 40) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            // Ignore vibration errors gracefully
        }
    }
}
